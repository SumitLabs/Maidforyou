import { Link } from 'react-router-dom';
import './articles.css';
import { FaRegCalendarDays } from "react-icons/fa6";
import { MdWhatsapp, MdEmail, MdPhone } from "react-icons/md";

const Articles = () => {
  return (
    <div className="article">
      <div className="inner_article">
        <img src="/images/img_02.jpg" alt="img..." />
        <div className="article_overlay flex_box flex_col ">
          <div className="article_title">
            <h3>Sem Porta Mollis Parturient</h3>

          </div>
          <div className="article_date flex_box ">
            <FaRegCalendarDays />
            <p>21 Fab 2024</p>
          </div>
        </div>
      </div>
      <div className=" article flex_box">
        <div className="posted_date flex_box">
          <div className="calendar_icon">
            <FaRegCalendarDays />
          </div>

          <div className="data">
            <div className="day">
              21
            </div>
            <div className="month">
              <p>Feb</p>
            </div>
            <div className="year">
              <p>2025</p>
            </div>
          </div>

        </div>
        <div className="post_content">
          <h3>
            Sem Porta Mollis Parturient
          </h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit laudantium quibusdam ad velit quos,
            a deleniti deserunt praesentium nisi quasi voluptates ullam nihil minus nostrum quo commodi libero laboriosam
            optio?Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis quae enim ullam id. Aliquam, provident
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit laudantium quibusdam ad velit quos,
            a deleniti deserunt praesentium nisi quasi voluptates ullam nihil minus nostrum quo commodi libero laboriosam
            optio?Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis quae enim ullam id. Aliquam, provident
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit laudantium quibusdam ad velit quos,
            a deleniti deserunt praesentium nisi quasi voluptates ullam nihil minus nostrum quo commodi libero laboriosam
            optio?Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis quae enim ullam id. Aliquam, provident
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit laudantium quibusdam ad velit quos,
            a deleniti deserunt praesentium nisi quasi voluptates ullam nihil minus nostrum quo commodi libero laboriosam
            optio?Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis quae enim ullam id. Aliquam, provident
            nemo amet rerum similique velit recusandae nesciunt, voluptates corporis laborum corrupti sunt sed nobis? Quos!
          </p>
        </div>
        <div className="aside">
          <div className="box">
            <h4 >Social Network</h4>
            <ul className="social_links aside_social_links flex_box">
              <li><Link to=""><MdWhatsapp /></Link></li>
              <li><Link to=""><MdEmail /></Link></li>
              <li><Link to=""><MdPhone /></Link></li>
            </ul>
          </div>


        </div>
      </div>
    </div>
  );
};

export default Articles;
