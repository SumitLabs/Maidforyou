import './blogcard.css'
import { Link } from 'react-router-dom'
import { BiSolidSend } from "react-icons/bi";
import { FaCommentAlt, FaRegThumbsUp, FaRegThumbsDown  } from "react-icons/fa";
import { useState } from 'react';
const BlogCard = () => {
    let [like, setLike] = useState(false)
    let likeToggle = () => {
        setLike(!like)
    }

    return (
        <div className="post_card">
            <div className="img">
                <img src="images/dummy_image.png" alt="" />
            </div>
            <div className="detail">
                <div className="post_title">
                    <h4>Get Professional Service in Kolkata</h4>
                    <div className="posted_on">
                        <p>2 months ago</p>
                    </div>
                </div>
                <div className="post_deception">
                    <p>One of the standout options offered by many maid agencies in Chandigarh is moppin maid services.
                        This specialized service focuses on deep cleaning and maintaining the cleanliness ...</p>
                </div>
            </div>
            <div className="post_footer flex_box">
                <div className="f_left flex_box">
                    <div className="icons" onClick={likeToggle}>
                        {
                            like ? <FaRegThumbsDown  /> : <FaRegThumbsUp />
                        }
                    </div>
                    <div className="icons">
                        <FaCommentAlt />
                    </div>

                </div>
                <div className="f_right">
                    <Link to="/articles/:126" className='read_more flex_box'>Read More <BiSolidSend /> </Link>
                </div>
            </div>

        </div>
    )
}

export default BlogCard