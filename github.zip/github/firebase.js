// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDauZQikG11gE-UpK_nwmN3PYWW-wrACDc",
  authDomain: "maidforyou-1ba95.firebaseapp.com",
  projectId: "maidforyou-1ba95",
  storageBucket: "maidforyou-1ba95.firebasestorage.app",
  messagingSenderId: "379687471943",
  appId: "1:379687471943:web:959f18acd8b7feed34da62"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);