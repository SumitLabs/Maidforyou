import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import Home from './pages/Home'
import Allrounders from './pages/Allrounders'
import Caretaker from './pages/Caretaker'
import CookingMaid from './pages/CookingMaid'
import Contact from './pages/Contact'
import ElderlyCare from './pages/ElderlyCare'
import HouseMaid from './pages/HouseMaid'
import About from './pages/About'
import { ErrorPage } from './ErrorPage'
import Posts from './pages/Posts'
import Articles from './pages/articles'
import Layout from './layout'

import './index.css'
const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    errorElement: <ErrorPage />,
    children: [
      {
        index: true,
        element: <Home />
      },
      {
        path: '/allrounders',
        element: <Allrounders />
      },
      {
        path: '/caretaker',
        element: <Caretaker />
      },
      {
        path: '/cookingmaid',
        element: <CookingMaid />
      },
      {
        path: '/housemaid',
        element: <HouseMaid />
      },
      {
        path: '/elderlycare',
        element: <ElderlyCare />
      },
      {
        path: '/about',
        element: <About />
      },
      {
        path: '/contact',
        element: <Contact />
      },
      {
        path: '/posts',
        element: <Posts />
      },
      {
        path: '/articles/:id',
        element: <Articles />
      }
    ]
  }
])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
