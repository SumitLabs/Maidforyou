import "./hero.css";
import {
  IoCallSharp,
  IoChatbubbleSharp,
  IoArrowForward,
} from "react-icons/io5";
import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <div className="hero">
      <div className="overly flex_box">
        <div className="support_info">
          <h1>Your Domestic Support Solution</h1>
          <div className="services">
            <p>
              All-Rounders | Baby Caretaker | Culinary Expert | Housekeeping Pro
              | Elderly Care
            </p>
          </div>
          <p>
            Welcome to MaidForYou, your go-to destination for premium home
            assistance. We&apos;re here to make household management effortless,
            so you can focus on what truly matters. Life gets busy, and keeping
            up with daily chores can be overwhelming—that’s where we come in.
            Our skilled professionals provide reliable and efficient services,
            bringing ease and convenience to your home.
          </p>

          <div className="flex_box flex_btn">
            <button className="call">
              <IoCallSharp />
              Call Us
            </button>

            <button className="chat">
              <Link to="https://wa.me/+918368204388?Hello" target="_blank">
                <IoChatbubbleSharp />
                Chat With Us
              </Link>
            </button>
          </div>
        </div>
        <div className="support_form">
          <h3>
            Don&apos;t hesitate to reach out to us for your home assistance
            needs.
          </h3>
          <form
            action="https://formspree.io/f/maneyddr"
            method="POST"
            className="flex_box flex_col flex_form"
          >
            <select id="services" name="Type of Services">
              <option value="all-rounders">All-rounders</option>
              <option value="baby_caretaker">Baby Caretaker</option>
              <option value="cooking_maid">Cooking Maid</option>
              <option value="house_maid">House Maid</option>
              <option value="elderly_care">Elderly Care</option>
            </select>
            <input
              type="text"
              name="Name"
              placeholder="Name"
              required
              autoComplete="OFF"
            />
            <input
              type="text"
              name="Phone Number"
              placeholder="Phone Number"
              required
              autoComplete="OFF"
            />
            <div className="flex_btn">
              <button className="call">
                Get a callback
                <IoArrowForward />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Hero;
