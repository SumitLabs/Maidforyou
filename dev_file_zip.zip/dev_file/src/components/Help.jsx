import "./help.css";
import { IoArrowForward } from "react-icons/io5";
const Help = () => {
  return (
    <section className="help">
      <div className="callback-container  flex_box">
        <p>Contact us today to discuss your domestic help needs.</p>
        <form
          className="callback-form"
          action="https://formspree.io/f/mblgjazw"
          method="POST"
        >
          <select required name="Type of Service">
            <option value="all-rounders">All-rounders</option>
            <option value="cooks">Cooks</option>
            <option value="baby_caretaker">Baby Caretaker</option>
            <option value="cooking_maid">Cooking Maid</option>
            <option value="house_maid">House Maid</option>
            <option value="elderly_care">Elderly Care</option>

          </select>

          <input type="text" placeholder="Name *" autoComplete="OFF" required  name="Name"/>

          <input type="tel" placeholder="Phone number *" autoComplete="OFF" required name="Phone Number" />

          <button type="submit">
            Get a callback <IoArrowForward />
          </button>
        </form>
      </div>
    </section>
  );
};

export default Help;
