import './servicehero.css'

const ServiceHero = (props) => {
    return (
        <div className="service_hero">

            <img src={props.img} alt="" />
            <div className="service_hero_r flex_box">
                <h3>{props.header}</h3>
                <p>{props.para}</p>
            </div>
        </div>

    )
}

export default ServiceHero