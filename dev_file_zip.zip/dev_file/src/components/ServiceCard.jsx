import './servicecard.css'
import { Link } from 'react-router-dom'
const ServiceCard = (props) => {
  return (
    <div className="service_card flex_box">
      <img src={props.img} alt="" />
      <div className="info">
        <h3>{props.title}</h3>
        <p>{props.para}</p>
      </div>
      <Link  className="service_card_footer flex_box">
        <p>Book Now</p>
      </Link>
    </div>
  )
}

export default ServiceCard