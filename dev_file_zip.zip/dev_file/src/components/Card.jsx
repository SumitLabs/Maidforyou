import { Link } from 'react-router-dom'
import './card.css'
import { IoArrowForward } from "react-icons/io5";
const Card = (props) => {
    return (
        <div className="card">
            <div className="card_title">
                <h3>{props.card_title}</h3>
            </div>
            <div className="card_content">
            <p>{props.card_content}</p>
            </div>
            <Link to={props.card_link} className="card_footer">
                <h4>Get Started</h4>
                <IoArrowForward/>
            </Link>

        </div>
    )
}

export default Card