import './feature.css'

const Features = (props) => {
  return (
    <section className="feature container">
        <img src={props.img} alt=""/>
        <div className="feature_des">
          <h3>{props.title}</h3>
          <p>{props.para}</p>
        </div>
    </section>
  )
}

export default Features