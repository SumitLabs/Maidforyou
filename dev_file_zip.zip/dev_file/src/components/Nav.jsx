import './nav.css';
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { MdWhatsapp, MdOutlineArrowDropDown, MdPhone } from "react-icons/md";
import { TiTimes, TiThMenu } from "react-icons/ti";

const Nav = () => {
    const [dropdown, setDropdown] = useState(false);
    const [hamburger, setHamburger] = useState(false);
    const [isLargeScreen, setIsLargeScreen] = useState(window.innerWidth > 768);

    // Toggle hamburger menu
    const toggleHamburger = () => {
        setHamburger(!hamburger);
    };

    // Toggle dropdown menu
    const toggleDropdown = (e) => {
        e.stopPropagation(); // Prevent event bubbling
        setDropdown(!dropdown);
    };

    // Handle window resize to auto-hide hamburger menu
    useEffect(() => {
        const handleResize = () => {
            setIsLargeScreen(window.innerWidth > 768);
            if (window.innerWidth > 768) {
                setHamburger(false); // Auto-hide menu on larger screens
            }
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    return (
        <nav className="navbar flex_box">
            <div className="logo">
                <Link to="/"><h2>Maidforyou</h2></Link>
            </div>

            {/* Nav Links */}
            <ul className={`nav_links ${hamburger ? 'active' : ''} ${isLargeScreen ? 'desktop' : 'mobile'}`}>
                <li className="dropdown">
                    <span className="dropdown_icon" >
                        <Link to="#" onClick={toggleDropdown}>Services<MdOutlineArrowDropDown /></Link>
                    </span>
                    {dropdown && (
                        <ul className="dropdown_menu">
                            <li>
                                <Link to="/allrounders" className='flex_box '>
                                    <div className="menu_icon"><img src="/icons/allrounders.png" alt="" /></div>
                                    <div className="menu"><h3>All-rounders</h3><p>Versatile professionals: housekeeping and cooking experts all-in-one!</p></div>
                                </Link>
                            </li>
                            <li>
                                <Link to="/caretaker" className='flex_box '>
                                    <div className="menu_icon"><img src="/icons/babycaretaker.png" alt="" /></div>
                                    <div className="menu"><h3>Baby Caretaker</h3><p>Infant specialist, nurturing, feeding, diapering, soothing, loving.</p></div>
                                </Link>
                            </li>
                            <li>
                                <Link to="/cookingmaid" className='flex_box '>
                                    <div className="menu_icon"><img src="/icons/cookingmaid.png" alt="" /></div>
                                    <div className="menu"><h3>Cooking Maid</h3><p>Culinary experts, meal preparation, kitchen cleaning, skilled professionals.</p></div>
                                </Link>
                            </li>
                            <li>
                                <Link to="/housemaid" className='flex_box '>
                                    <div className="menu_icon"><img src="/icons/housemaid.png" alt="" /></div>
                                    <div className="menu"><h3>House Maid</h3><p>Domestic helper, cleaning, cooking, laundry, trustworthy, reliable.</p></div>
                                </Link>
                            </li>
                            <li>
                                <Link to="/elderlycare" className='flex_box '>
                                    <div className="menu_icon"><img src="/icons/elderlycare.png" alt="" /></div>
                                    <div className="menu"><h3>Elderly Care</h3><p>Caregiver, companionship, medication assistance, hygiene support, trustworthy, attentive.</p></div>
                                </Link>
                            </li>
                        </ul>
                    )}

                </li>
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
                <li><Link to="/posts">Posts</Link></li>
            </ul>

            {/* Social Links */}
            <ul className="flex_box social_links">
                <li><Link to="https://wa.me/+918368204388?Hello" target="_blank"><MdWhatsapp /></Link></li>
                <li><Link to=""><MdPhone /></Link></li>
            </ul>

            {/* Hamburger Menu */}
            <div className="hamburger" onClick={toggleHamburger}>
                {hamburger ? <TiTimes /> : <TiThMenu />}
            </div>
        </nav>
    );
};

export default Nav;
