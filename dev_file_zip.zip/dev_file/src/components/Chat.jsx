import './chat.css'
import { Link } from "react-router-dom"
import { FaWhatsapp } from "react-icons/fa";
const Chat = () => {
  return (
    <Link to ="https://wa.me/+918368204388?Hello" target="_blank" className="whatsapp_btn flex_box">
    <FaWhatsapp/>
    <p>Click to Chat</p>
    </Link>
  )
}

export default Chat