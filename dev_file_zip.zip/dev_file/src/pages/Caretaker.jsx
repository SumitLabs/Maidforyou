import ServiceHero from '../components/ServiceHero'
import './allrounders.css'
import Counter from '../components/Counter'
import Title from '../components/Title'
import Help from '../components/Help'
import Review from '../components/Review'
import Features from '../components/Feature'
import FAQ from '../components/FAQ'
const Caretaker = () => {
  let quesAns = [{
    ques: "What qualifications and experience do your Baby Caretakers have?",
    ans: "Our Baby Caretakers have extensive experience in caring for infants and toddlers. They undergo thorough background checks and are trained in baby care, first aid, and child development."
  },
  {
    ques: "Can I customize the baby care routine based on my baby's needs?",
    ans: "Absolutely! Our Baby Caretakers tailor the care routine to accommodate your baby's preferences, feeding schedule, and sleep routines, ensuring a personalized and nurturing experience."
  },
  {
    ques: "How do you ensure the safety and security of my baby?",
    ans: "Your baby's safety is our top priority. Our Baby Caretakers are trained to follow strict safety protocols, including secure supervision, safe sleep practices, and childproofing measures."
  },
  {
    ques: "Are your Baby Caretakers available for overnight care?",
    ans: `Yes, we offer overnight baby care services for parents who need assistance during nighttime hours. Our caretakers are available to ensure your baby's comfort and well-being.`
  },

  ]
  let service_hero = [{
    img: "/images/img05.jpg",
    title: "Experienced Caretakers",
    para: `Your dependable professionals in versatile domestic assistance.`
  },
  {
    img: "/images/img06.jpg",
    title: "Nurturing Environment",
    para: `Our Baby Caretakers bring a wealth of experience to nurturing and safeguarding infants and toddlers, guaranteeing their safety and happiness.`
  },
  {
    img: "/images/img07.jpg",
    title: "Flexible Scheduling",
    para: `Parenting comes with unique schedules, and our Baby Caretaker services adapt to your timing needs, providing the care your child deserves.`
  }
  ]
  return (
    <div className="allrounder">
      <div className="container">
        <ServiceHero img="/images/img_05.png"
          header="Baby Caretaker/Japa Maid"
          para="Delivering Tender and Skilled Care for Your Beloved Little Ones. Count on our Proficient Baby Caretakers to establish a secure and nurturing environment, so you can concentrate on your everyday commitments with confidence." />
      </div>
      <Counter />
      <div className="features_container">
        <Title title="Features" title_des="Your trusted experts in multifaceted domestic help services." />
        <div className="container flex_box" >
          {service_hero.map((item, index) => (
            <div key={index}>
              <Features
                img={item.img}
                title={item.title}
                para={item.para}
              />
            </div>
          ))}
        </div>
      </div>
      <div className="contact-form flex_box flex_col full_width">
        <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

        <form className='half_width'>
          <label>Service</label>
          <select required>
            <option value="all-rounders">All-rounders</option>
            <option value="cleaners">Cleaners</option>
            <option value="cooks">Cooks</option>
          </select>

          <label>Name *</label>
          <input type="text" placeholder="Enter your name" required autoComplete="OFF" />

          <label>Phone number *</label>
          <input type="tel" placeholder="Enter your 10 digit mobile number" required autoComplete="OFF"/>
          <input type='submit' />

        </form>
      </div>

      <section className="FAQs">
        <Title
          title="FAQ's"
          title_des="Find Answers to Your Queries About Our Domestic Help Services."
        />
        {
          quesAns.map((item, index) => (
            <div key={index}>
              <FAQ ques={item.ques} ans={item.ans} />
            </div>
          ))
        }

      </section>


      <section className='reviews'>
        <Title
          title="Our reviews"
          title_des="Discover what our happy customers have to say about our reliable
                             and trustworthy domestic help hiring services."
        />
        <div className="review_section container flex_box">
          <Review say="I’ve been using this service for a few months now, and I am beyond satisfied. My housemaid is friendly, hardworking, and very professional. Couldn’t ask for more!" name="Neha"/>
          <Review say="Meal prep used to be such a hassle, but thanks to my cooking maid, I now enjoy fresh and tasty meals every day! She’s a fantastic cook and adapts recipes to my preferences." name="Kiran"/>
          <Review say="Our baby caretaker is so loving and attentive! She engages my child in fun activities and ensures proper hygiene and care. I can work stress-free knowing my baby is in good hands." name="Meera"/>
        </div>
      </section>
      <section className='org_info flex_box container'>
                <div className="address">
                    <h3>Maidforyou</h3>
                    <address>
                        Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi -110077
                    </address>
                    <div className="contact_info">
                        <p><span>phone :</span>+91 8368204388 </p>
                        <p><span>wathsapp :</span>+91 8368204388 </p>
                    </div>
                </div>
                <div className="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
                </div>
            </section>
      <Help />
    </div>
  )
}

export default Caretaker