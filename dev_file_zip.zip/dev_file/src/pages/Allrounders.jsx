import ServiceHero from '../components/ServiceHero'
import './allrounders.css'
import Counter from '../components/Counter'
import Title from '../components/Title'
import Help from '../components/Help'
import Review from '../components/Review'
import Features from '../components/Feature'
import FAQ from '../components/FAQ'
const Allrounders = () => {
  let quesAns = [{
    ques: "What services do your All-Rounders offer?",
    ans: "Our All-Rounders excel in cooking, cleaning and housekeeping, providing a comprehensive range of domestic help services."
  },
  {
    ques: "How do I schedule services with an All-Rounder?",
    ans: "Scheduling is easy! Simply contact us with your requirements, and we'll match you with the most suitable All-Rounder for your needs."
  },
  {
    ques: "Can I request assistance with multiple tasks from the same All-Rounder?",
    ans: "Absolutely! Our All-Rounders are flexible and can assist with various tasks, making your domestic help experience seamless and efficient."
  },
  {
    ques: "Are your All-Rounders experienced and trained professionals?",
    ans: "Yes, our All-Rounders undergo rigorous screening and training to ensure they are skilled, reliable, and committed to delivering exceptional service."
  },
  {
    ques: "What if I have specific preferences or dietary requirements for cooking tasks?",
    ans: "Our All-Rounders are attentive to your preferences and dietary needs. Simply communicate your requirements, and they will tailor their services accordingly."
  },
  ]
  let service_hero = [{
    img: "/images/img02.jpg",
    title: "All-Rounder House Maid Services",
    para: `We are introducing our skilled experts who shine in a range of household responsibilities. From preparing delicious meals to maintaining cleanliness, and managing your home, our all-rounders guarantee a harmonious and effortless home life.`
  },
  {
    img: "/images/img03.jpg",
    title: "All-Rounder House Maid Services",
    para: `We are introducing our skilled experts who shine in a range of household responsibilities. From preparing delicious meals to maintaining cleanliness, and managing your home, our all-rounders guarantee a harmonious and effortless home life.`
  },
  {
    img: "/images/img04.jpg",
    title: "All-Rounder House Maid Services",
    para: `We are introducing our skilled experts who shine in a range of household responsibilities. From preparing delicious meals to maintaining cleanliness, and managing your home, our all-rounders guarantee a harmonious and effortless home life.`
  }
  ]
  return (
    <div className="allrounder">
      <div className="container">
        <ServiceHero img="/images/img_03.png"
          header="All-Rounder House Maid Services"
          para="We are introducing our skilled experts who shine in a range of household responsibilities. From preparing delicious meals to maintaining cleanliness, and managing your home, our all-rounders guarantee a harmonious and effortless home life." />
      </div>
      <Counter />
      <div className="features_container">
        <Title title="Features" title_des="Your trusted experts in multifaceted domestic help services." />
        <div className="container flex_box" >
          {service_hero.map((item, index) => (
            <div key={index}>
              <Features
                img={item.img}
                title={item.title}
                para={item.para}
              />
            </div>
          ))}
        </div>
      </div>
      <div className="contact-form flex_box flex_col full_width">
        <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

        <form className='half_width'>
          <label>Service</label>
          <select required>
            <option value="all-rounders">All-rounders</option>
            <option value="cleaners">Cleaners</option>
            <option value="cooks">Cooks</option>
          </select>

          <label>Name *</label>
          <input type="text" placeholder="Enter your name" required />

          <label>Phone number *</label>
          <input type="tel" placeholder="Enter your 10 digit mobile number" required />
          <input type='submit' />

        </form>
      </div>

      <section className="FAQs">
        <Title
          title="FAQ's"
          title_des="Find Answers to Your Queries About Our Domestic Help Services."
        />
        {
          quesAns.map((item, index) => (
            <div key={index}>
              <FAQ ques={item.ques} ans={item.ans} />
            </div>
          ))
        }

      </section>


      <section className='reviews'>
        <Title
          title="Our reviews"
          title_des="Discover what our happy customers have to say about our reliable
                               and trustworthy domestic help hiring services."
        />
        <div className="review_section container flex_box">
          <Review  say="I needed an all-in-one helper, and the one provided by this service exceeded my expectations! From cleaning and cooking to babysitting, she does everything with care and professionalism. This has made my life so much easier. Thank you!" name="Megha"/>
          <Review say="The maid we hired is amazing! She is efficient, polite, and incredibly hardworking. Our home has never been cleaner. Thank you for the great service!" name="Pooja varma"/>
          <Review say="I was hesitant to leave my baby with someone new, but the caretaker we found through this service is like family now. She is caring, responsible, and keeps my baby happy and safe." name="Arun"/>
        </div>
      </section>
    
      <section className='org_info flex_box container'>
                <div className="address">
                    <h3>Maidforyou</h3>
                    <address>
                        Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi -110077
                    </address>
                    <div className="contact_info">
                        <p><span>phone :</span>+91 8368204388</p>
                        <p><span>wathsapp :</span>+91 8368204388</p>
                    </div>
                </div>
                <div className="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
                </div>
            </section>
      <Help />
    </div>
  )
}

export default Allrounders