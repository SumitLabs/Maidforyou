import Title from '../components/Title'
import './posts.css'
import BlogCard from '../components/BlogCard'
const Posts = () => {
  return (
    <section className="post">
      <Title title="Posts" title_des="Explore Informative Articles and Insights on a Variety of Services in Our Posts Section!"/>
      <div className="posts container flex_box">
       <BlogCard/>
      </div>
    </section>
  )
}

export default Posts