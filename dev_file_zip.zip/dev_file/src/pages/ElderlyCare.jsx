import ServiceHero from "../components/ServiceHero";
import "./allrounders.css";
import Counter from "../components/Counter";
import Title from "../components/Title";
import Help from "../components/Help";
import Review from "../components/Review";
import Features from "../components/Feature";
import FAQ from "../components/FAQ";

const ElderlyCare = () => {
  let quesAns = [
    {
      ques: "What services does your Elderly Care provide?",
      ans: "Our Elderly Care specialists offer personalized care plans, companionship, health monitoring, and a range of support services to ensure the well-being and comfort of your loved ones.",
    },
    {
      ques: "How do I arrange Elderly Care services for my family member?",
      ans: "Arranging Elderly Care is simple! Contact us with your requirements, and we will match you with a dedicated specialist to meet the unique needs of your loved one.",
    },
    {
      ques: "Can I request both companionship and health monitoring from the same Elderly Care specialist?",
      ans: "Certainly! Our Elderly Care specialists are versatile, providing both companionship and health monitoring. This ensures a comprehensive and caring approach to your loved one's well-being.",
    },
    {
      ques: "Are your Elderly Care specialists trained and experienced in handling diverse needs?",
      ans: "Yes, our Elderly Care specialists undergo thorough training and screening. They are skilled, compassionate professionals dedicated to providing excellent care and companionship.",
    },
    {
      ques: "What if my loved one has specific health requirements or preferences?",
      ans: "Our Elderly Care specialists are attentive to individual needs. Communicate any health requirements or preferences, and they will tailor their services to ensure a comfortable and supportive experience.",
    },
  ];
  let service_hero = [
    {
      img: "/images/img14.jpg",
      title: "Culinary Expertise",
      para: `Our Cooking Maids are culinary artists, proficient in various cuisines and cooking techniques. They craft delectable, personalized meals that cater to your unique taste buds.`,
    },
    {
      img: "/images/img15.jpg",
      title: "Customized Menus",
      para: `Experience menu customization at its best with our Cooking Maids. They adeptly cater to dietary preferences, allergies, and special requests, ensuring your culinary delights are precisely as you desire.`,
    },
    {
      img: "/images/img16.jpg",
      title: "Meal Preparation Efficiency",
      para: `Let our Cooking Maids manage meal planning, grocery shopping, and cooking, giving you the luxury of savoring gourmet meals without the fuss.`,
    },
  ];
  return (
    <div className="allrounder">
      <div className="container">
        <ServiceHero
          img="/images/img_08.png"
          header="Elderly Care Specialists"
          para="Meet our dedicated experts adept at comprehensive elderly care services. From ensuring physical well-being to offering companionship, our professionals create a nurturing environment for your loved ones, ensuring their comfort and happiness."
        />
      </div>
      <Counter />
      <div className="features_container">
        <Title
          title="Features"
          title_des="Your trusted experts in multifaceted domestic help services."
        />
        <div className="container flex_box">
          {service_hero.map((item, index) => (
            <div key={index}>
              <Features img={item.img} title={item.title} para={item.para} />
            </div>
          ))}
        </div>
      </div>
      <div className="contact-form flex_box flex_col full_width">
        <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

        <form className="half_width">
          <label>Service</label>
          <select required>
            <option value="all-rounders">All-rounders</option>
            <option value="cleaners">Cleaners</option>
            <option value="cooks">Cooks</option>
          </select>

          <label>Name *</label>
          <input type="text" placeholder="Enter your name" required />

          <label>Phone number *</label>
          <input
            type="tel"
            placeholder="Enter your 10 digit mobile number"
            required
          />
          <input type="submit" />
        </form>
      </div>

      <section className="FAQs">
        <Title
          title="FAQ's"
          title_des="Find Answers to Your Queries About Our Domestic Help Services."
        />
        {quesAns.map((item, index) => (
          <div key={index}>
            <FAQ ques={item.ques} ans={item.ans} />
          </div>
        ))}
      </section>

      <section className="reviews">
        <Title
          title="Our reviews"
          title_des="Discover what our happy customers have to say about our reliable
                               and trustworthy domestic help hiring services."
        />
        <div className="review_section container flex_box">
          <Review
            say="The professionalism of the maid provided by this service is impressive. She manages household chores efficiently, is always on time, and respects our home. Truly a great experience!"
            name="Sandeep"
          />
          <Review
            say="The housemaid we hired is well-trained and takes great care of our home. She is polite, honest, and always goes the extra mile. We are so grateful!"
            name="Rashmi"
          />
          <Review
            say="From booking the service to having the right professional assigned, everything was seamless. The maid is well-trained and courteous. I will definitely continue using this service!"
            name="Simran"
          />
        </div>
      </section>
      <section className="org_info flex_box container">
        <div className="address">
          <h3>Maidforyou</h3>
          <address>
            Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi
            -110077
          </address>
          <div className="contact_info">
            <p>
              <span>phone :</span>+91 8368204388 
            </p>
            <p>
              <span>wathsapp :</span>+91 8368204388 
            </p>
          </div>
        </div>
        <div className="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
        </div>
      </section>
      <Help />
    </div>
  );
};

export default ElderlyCare;
