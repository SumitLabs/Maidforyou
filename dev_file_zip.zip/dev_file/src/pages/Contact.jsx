import './contact.css'
import Title from '../components/Title'
import { MdLocationOn } from "react-icons/md";
import { MdCall } from "react-icons/md";
// import { MdEmail } from "react-icons/md";
const Contact = () => {
  return (
    <div className="contact">
      <Title title="Contact Us" title_des="Our Team is Ready to Assist You with Any Questions or Concerns." />

      <div className="container contact_container flex_box">
        <div className="contact-info ">
          <div className="flex_box info_icon">
            <MdLocationOn />
            <h2> Location :</h2>
          </div>

          <p>Maidforyou</p>
          <address>
            Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi -110077
          </address>
          <div className="flex_box info_icon">
            <MdCall />
            <h2> Call :</h2>
          </div>

          <a href="">+91 8368204388</a>
          <div className="flex_box info_icon">
            {/* <MdEmail />
            <h2> Email :</h2> */}
          </div>

          {/* Email Embed hear */}

          {/* Google Map Embed */}
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
        </div>

        {/* Right Section: Contact Form */}
        <div className="contact-form">
          <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

          <form
           action="https://formspree.io/f/maneyddr"
            method="POST"
          >
            <label>Service</label>
            <select required name='Type of Service'>
            <option value="all-rounders">All-rounders</option>
              <option value="baby_caretaker">Baby Caretaker</option>
              <option value="cooking_maid">Cooking Maid</option>
              <option value="house_maid">House Maid</option>
              <option value="elderly_care">Elderly Care</option>
            </select>

            <label>Name *</label>
            <input type="text" placeholder="Enter your name" required  name='Name'/>

            <label>Phone number *</label>
            <input type="tel" placeholder="Enter your 10 digit mobile number" required name='Phone Number'/>
            <input type='submit' />

          </form>
        </div>
      </div>
    </div>
  )
}


export default Contact