import ServiceHero from '../components/ServiceHero'
import './allrounders.css'
import Counter from '../components/Counter'
import Title from '../components/Title'
import Help from '../components/Help'
import Review from '../components/Review'
import Features from '../components/Feature'
import FAQ from '../components/FAQ'
const HouseMaid = () => {
  let quesAns = [{
    ques: "How do you ensure the reliability of your House Maids?",
    ans: "We conduct rigorous background checks and thorough screening processes to ensure that our House Maids are trustworthy and reliable professionals."
  },
  {
    ques: "Can I request specific cleaning tasks to be included in the service?",
    ans: "Yes, our House Maids are happy to accommodate your specific cleaning preferences. You can communicate your requirements, and they will tailor the service accordingly."
  },
  {
    ques: "Are your House Maids available on a regular schedule or for one-time cleanings?",
    ans: "We offer both regular cleaning schedules (weekly, bi-weekly, monthly) and one-time cleaning services, allowing you to choose the option that suits your needs."
  },
  {
    ques: "What safety measures are in place during the COVID-19 pandemic?",
    ans: "We prioritize the safety of our clients and House Maids. Our team adheres to strict COVID-19 safety protocols, including wearing masks and practicing social distancing during cleaning sessions."
  },

  ]
  let service_hero = [{
    img: "/images/img11.jpg",
    title: "Meticulous Cleaning",
    para: `Our House Maids are meticulous masters of cleanliness, leaving no corner unattended in their quest for a spotless and orderly home.`
  },
  {
    img: "/images/img12.jpg",
    title: "Customized Cleaning Plans",
    para: `Our cleaning plans are like a wardrobe of options – choose what suits you best. Tailor your cleaning sessions to match your exact preferences and cleaning priorities.`
  },
  {
    img: "/images/img13.jpg",
    title: "Trustworthy Professionals",
    para: `Our House Maids are the foundation of trustworthiness. Rigorously vetted and background-checked, they bring reliability and peace of mind to your home.`
  }
  ]
  return (
    <div className="allrounder">
      <div className="container">
        <ServiceHero img="/images/img_07.png"
          header="House Maid"
          para="Embrace Home Bliss with Our Masterful House Maids Our skilled cleaners work their magic, turning your residence into a sanctuary of pristine serenity. Sit Back, Relax, and Let Our Dedicated Cleaners work impress you." />
      </div>
      <Counter />
      <div className="features_container">
        <Title title="Features" title_des="Your trusted experts in multifaceted domestic help services." />
        <div className="container flex_box" >
          {service_hero.map((item, index) => (
            <div key={index}>
              <Features
                img={item.img}
                title={item.title}
                para={item.para}
              />
            </div>
          ))}
        </div>
      </div>
      <div className="contact-form flex_box flex_col full_width">
        <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

        <form className='half_width'>
          <label>Service</label>
          <select required>
            <option value="all-rounders">All-rounders</option>
            <option value="cleaners">Cleaners</option>
            <option value="cooks">Cooks</option>
          </select>

          <label>Name *</label>
          <input type="text" placeholder="Enter your name" required />

          <label>Phone number *</label>
          <input type="tel" placeholder="Enter your 10 digit mobile number" required />
          <input type='submit' />

        </form>
      </div>

      <section className="FAQs">
        <Title
          title="FAQ's"
          title_des="Find Answers to Your Queries About Our Domestic Help Services."
        />
        {
          quesAns.map((item, index) => (
            <div key={index}>
              <FAQ ques={item.ques} ans={item.ans} />
            </div>
          ))
        }

      </section>


      <section className='reviews'>
        <Title
          title="Our reviews"
          title_des="Discover what our happy customers have to say about our reliable
                           and trustworthy domestic help hiring services."
        />
        <div className="review_section container flex_box">
          <Review say="The professionalism of the maid provided by this service is impressive. She manages household chores efficiently, is always on time, and respects our home. Truly a great experience!" name="Sandeep"/>
          <Review say="The housemaid we hired is well-trained and takes great care of our home. She is polite, honest, and always goes the extra mile. We are so grateful!" name="Rashmi"/>
          <Review say="From booking the service to having the right professional assigned, everything was seamless. The maid is well-trained and courteous. I will definitely continue using this service!" name="Simran"/>
        </div>
      </section>
      <section className='org_info flex_box container'>
        <div className="address">
          <h3>Maidforyou</h3>
          <address>
            Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi -110077
          </address>
          <div className="contact_info">
            <p><span>phone :</span> +91 7703888274</p>
            <p><span>wathsapp :</span> +91 7703888274</p>
          </div>
        </div>
        <div className="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
        </div>
      </section>
      <Help />
    </div>
  )
}

export default HouseMaid