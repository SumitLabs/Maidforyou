import ServiceHero from '../components/ServiceHero'
import './allrounders.css'
import Counter from '../components/Counter'
import Title from '../components/Title'
import Help from '../components/Help'
import Review from '../components/Review'
import Features from '../components/Feature'
import FAQ from '../components/FAQ'
const CookingMaid = () => {
  let quesAns = [{
    ques: "What types of cuisine can your Cooking Maids prepare?",
    ans: "Our Cooking Maids are proficient in a wide range of cuisines, including local dishes, international flavors, and specialized diets."
  },
  {
    ques: "Can I request specific recipes or dishes for my meals?",
    ans: "Absolutely! You can share your favorite recipes or specific dishes you'd like to be prepared, and our Cooking Maids will be delighted to recreate them for you."
  },
  {
    ques: "Can your Cooking Maids accommodate dietary restrictions and allergies?",
    ans: "Yes, our Cooking Maids can cater to various dietary needs, including allergies, vegetarian, vegan, gluten-free, and more. Simply inform us of any specific requirements."
  },
  {
    ques: "Are your Cooking Maids available for special occasions or dinner parties?",
    ans: "Absolutely! Our Cooking Maids can curate a delectable menu for special occasions or dinner parties, adding a touch of culinary excellence to your gatherings."
  },

  ]
  let service_hero = [{
    img: "/images/img08.jpg",
    title: "Culinary Expertise",
    para: `Our Cooking Maids are culinary artists, proficient in various cuisines and cooking techniques. They craft delectable, personalized meals that cater to your unique taste buds.`
  },
  {
    img: "/images/img09.jpg",
    title: "Customized Menus",
    para: `Experience menu customization at its best with our Cooking Maids. They adeptly cater to dietary preferences, allergies, and special requests, ensuring your culinary delights are precisely as you desire.`
  },
  {
    img: "/images/img10.jpg",
    title: "Meal Preparation Efficiency",
    para: `Let our Cooking Maids manage meal planning, grocery shopping, and cooking, giving you the luxury of savoring gourmet meals without the fuss.`
  }
  ]
  return (
    <div className="allrounder">
    <div className="container">
      <ServiceHero img="/images/img_06.png"
        header="Cooking Maid"
        para="Enjoy Tasty Dishes Cooked by Our Skilled Cooking Maids.Satisfy Your Taste Buds with Flavorful Meals Prepared by Our Expert Cooking Maids. Experience Delicious and Exquisite Dishes Right at Your Dining Table." />
    </div>
    <Counter />
    <div className="features_container">
      <Title title="Features" title_des="Your trusted experts in multifaceted domestic help services." />
      <div className="container flex_box" >
        {service_hero.map((item, index) => (
          <div key={index}>
            <Features
              img={item.img}
              title={item.title}
              para={item.para}
            />
          </div>
        ))}
      </div>
    </div>
    <div className="contact-form flex_box flex_col full_width">
      <h2>Reach Out for Inquiries, Support, or to Book Our Services.</h2>

      <form className='half_width'>
        <label>Service</label>
        <select required>
          <option value="all-rounders">All-rounders</option>
          <option value="cleaners">Cleaners</option>
          <option value="cooks">Cooks</option>
        </select>

        <label>Name *</label>
        <input type="text" placeholder="Enter your name" required />

        <label>Phone number *</label>
        <input type="tel" placeholder="Enter your 10 digit mobile number" required />
        <input type='submit' />

      </form>
    </div>

    <section className="FAQs">
      <Title
        title="FAQ's"
        title_des="Find Answers to Your Queries About Our Domestic Help Services."
      />
      {
        quesAns.map((item, index) => (
          <div key={index}>
            <FAQ ques={item.ques} ans={item.ans} />
          </div>
        ))
      }

    </section>


    <section className='reviews'>
      <Title
        title="Our reviews"
        title_des="Discover what our happy customers have to say about our reliable
                           and trustworthy domestic help hiring services."
      />
      <div className="review_section container flex_box">
       
      <Review  name="Rashmi L." say="The housemaid we hired is well-trained and takes great care of our home. She is polite, honest, and always goes the extra mile. We are so grateful!"/>
      <Review  name="Simran D." say="From booking the service to having the right professional assigned, everything was seamless. The maid is well-trained and courteous. I will definitely continue using this service!"/>
      <Review  name="Kiran V." say="Meal prep used to be such a hassle, but thanks to my cooking maid, I now enjoy fresh and tasty meals every day! She’s a fantastic cook and adapts recipes to my preferences."/>
      
       
      </div>
    </section>
    <section className='org_info flex_box container'>
                <div className="address">
                    <h3>Maidforyou</h3>
                    <address>
                        Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi -110077
                    </address>
                    <div className="contact_info">
                        <p><span>phone : </span>+91 8368204388 </p>
                        <p><span>wathsapp : </span>+91 8368204388 </p>
                    </div>
                </div>
                <div className="map">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
                </div>
            </section>
    <Help />
  </div>
  )
}

export default CookingMaid