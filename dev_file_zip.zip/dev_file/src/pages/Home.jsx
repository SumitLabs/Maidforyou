import "./home.css";
import Hero from "../components/Hero";
import Title from "../components/Title";
import Card from "../components/Card";
import { IoCallSharp, IoChatbubbleSharp } from "react-icons/io5";
import ServiceCard from "../components/ServiceCard";
import Counter from "../components/Counter";
import Review from "../components/Review";
import Help from "../components/Help";
import { Link } from "react-router-dom";
let card = [
  {
    title: "Our Caregivers",
    content:
      "We choose passionate professionals devoted to delivering exceptional care for seniors. Through thorough screening and training, we ensure reliability, expertise, and a commitment to outstanding service.",
    link: "/about",
  },
  {
    title: "Convenient Flexibility",
    content:
      "Your convenience matters to us. We offer flexible scheduling, personalized services, and tailored solutions to fit your lifestyle, ensuring seamless, hassle-free assistance that integrates smoothly into your daily routine.",
    link: "/about",
  },
  {
    title: "Uncompromising Quality",
    content:
      "Excellence defines us. We perform regular quality checks and value customer feedback to uphold high standards, ensuring continuous improvement and superior service tailored to your needs.",
    link: "/about",
  },
];

let works = [
  {
    work: "Share Your Details",
    content:
      "Get started with expert home assistance. Provide your details to receive personalized and professional support for your household needs.",
  },
  {
    work: "Await Our Call",
    content:
      "Be prepared for our call, where we’ll discuss how our dedicated team can best meet your specific needs",
  },
  {
    work: "Get services at your home",
    content:
      "Easily oversee your home services from anywhere with real-time updates and communication right on your phone.",
  },
  {
    work: "Doorstep Delivery Services",
    content:
      "Conveniently handle your home services from your phone. Stay informed and connected with us anytime, anywhere.",
  },
];

const Home = () => {
  return (
    <section className="home">
      <Hero />
      <section>
        <Title
          title="Why Choose Us?"
          title_des="Our caregivers are carefully selected, professionally trained, and fully committed to providing seniors with compassionate care."
        />
        <div className="container">
          <div className="card_container flex_box">
            {card.map((item, index) => (
              <Card
                key={index}
                card_title={item.title}
                card_content={item.content}
                card_link={item.link}
              />
            ))}
          </div>
        </div>
        <div className="service flex_box">
          <div className="work">
            <Title
              title="How We Work"
              title_des="We've perfected a process to ensure that only the finest professionals, devoted to service excellence, join our family."
            />
            <div className="work_grid">
              {works.map((item, index) => (
                <div className="item" key={index}>
                  <ul>
                    <li>
                      <strong>{item.work}</strong>
                    </li>
                  </ul>
                  <p>{item.content}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="offer">
            <Title
              title="Our Offerings"
              title_des="We offer flexible scheduling to fit your busy lifestyle, ensuring both convenience and peace of mind."
            />
            <ul className="offers">
              <li>Highly Skilled Professionals</li>
              <li>Tailored Support</li>
              <li>Convenient Scheduling Options</li>
              <li>Dependability and Trust</li>
              <li>All-Inclusive Assistance</li>
              <li>Guaranteed Quality</li>
              <li>Security and Peace of Mind</li>
              <li>Committed to Your Satisfaction</li>
            </ul>

            <div className="flex_box flex_btn offers_btn">
              <button className="call">
                <IoCallSharp />
                Call Us
              </button>
              <button className="chat">
                <Link to="https://wa.me/+918368204388?Hello" target="_blank">
                  <IoChatbubbleSharp />
                  Chat With Us
                </Link>
              </button>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <Title
            title="Our Services Simplified"
            title_des="We excel in cooking, postnatal care, babysitting, and housekeeping,
                        making your home a well-managed haven."
          />
          <div className="services_cards flex_box">
            <ServiceCard
              title="All-rounders"
              para="Discover our versatile Home Assistants—experts in housekeeping, childcare, 
                            and cooking. From maintaining a tidy home to caring for your little ones and preparing 
                            delicious meals, they handle it all with skill and dedication."
              img="icons/allrounders.png"
            />
            <ServiceCard
              title="Baby Caretaker"
              para=" Our dedicated caregivers provide loving and attentive care for infants. 
                            They ensure safety, hygiene, and engaging activities, giving parents confidence 
                            and supporting the baby’s well-being and development."
              img="icons/babycaretaker.png"
            />
            <ServiceCard
              title="Cooking Maid"
              para="Our talented chefs bring flavorful, home-cooked meals to your table. 
                            They prepare customized dishes to suit your taste, ensuring a delightful 
                            dining experience in the comfort of your home."
              img="icons/cookingmaid.png"
            />
            <ServiceCard
              title="House Maid"
              para="Our professional cleaners offer 
                            top-notch housekeeping and organization services, keeping your home spotless and cozy.
                             Enjoy a clean, comfortable space without the hassle."
              img="icons/housemaid.png"
            />
          </div>
        </div>
      </section>
      <Counter />
      <section className="reviews">
        <Title
          title="Our reviews"
          title_des="Discover what our happy customers have to say about our reliable
                               and trustworthy domestic help hiring services."
        />
        <div className="review_section container flex_box">
          <Review
            say="The baby caretaker we hired is simply amazing! She is kind, patient, and truly cares for my child as if they were her own. It gives me great peace of mind knowing my little one is in safe hands while I work. Thank you for this wonderful service!"
            name="Rahul Sharma"
          />
          <Review
            say="My cooking maid has transformed our dining experience! She prepares fresh, healthy, and absolutely delicious meals tailored to our preferences. The convenience and quality of service are outstanding. I no longer worry about daily meal prep!"
            name="Sneha M."
          />
          <Review
            say="Finding a trustworthy and efficient housemaid was a challenge until I found this service. The selection process was seamless, and my maid is incredibly reliable, polite, and thorough with her work. My home has never looked better!"
            name="Vikram"
          />
        </div>
      </section>

      <section className="org_info flex_box container">
        <div className="address">
          <h3>Maidforyou</h3>
          <address>
            Plot no. 24 new no RZG SF palam colony Raj nagar part 2 delhi
            -110077
          </address>
          <div className="contact_info">
            <p>
              <span>phone :</span> +91 8368204388 
            </p>
            <p>
              <span>wathsapp :</span> +91 8368204388 
            </p>
          </div>
        </div>
        <div className="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13260.747729836288!2d77.07256654226927!3d28.58231472974061!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1b0042f75483%3A0xfd92213a303df401!2sRZG-361!5e0!3m2!1sen!2sin!4v1741546628393!5m2!1sen!2sin"></iframe>
        </div>
      </section>
      <Help />
    </section>
  );
};

export default Home;
