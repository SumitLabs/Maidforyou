import Title from "../components/Title"
import './about.css'
const About = () => {
  return (
    <section className="about">
      <Title title="About Us" title_des="Your Home, Our Mission: Delivering Exceptional Domestic Help Services with a Personal Touch." />
      <div className="about_us container">
        <p>
        At MaidForYou, we are dedicated to providing reliable and professional domestic assistance. Our journey started with a simple 
        mission—to make home management effortless for our clients. We recognize the challenges of balancing daily responsibilities, 
        which is why our goal is to offer trusted household support that brings ease and comfort to your life.
        </p>
        <b>Commitment to Quality Service</b>
        <p>Excellence is at the core of everything we do. From the moment you reach out, our team carefully understands your needs 
          to provide tailored solutions. We hand-select our professionals, ensuring they are skilled, experienced, and passionate 
          about delivering high-quality services. Every member of our team undergoes training to maintain professionalism, reliability, 
          and customer satisfaction.
        </p>

        <b>Enhancing Your Home Experience</b>

        <p>A well-managed home creates a stress-free and fulfilling life. Our wide range of services includes expert housekeeping, 
          meal preparation, child care, and overall home assistance. With our skilled team supporting you, you can enjoy more meaningful
          moments with your family and focus on what truly matters—without worrying about daily chores.
        </p>
         
         <b>Built on Trust and Transparency</b>
         <p>
         Your trust means everything to us. We value open communication and transparency, ensuring you have a clear understanding of our services, pricing, and policies. Beyond just assistance, we aim to build lasting relationships with our clients, consistently delivering reliable support that exceeds expectations.
         At MaidForYou, we believe in transforming homes into spaces of comfort and harmony. Whether you need a meticulous housekeeper, a talented cook, a caring babysitter, or an all-in-one home assistant, we are here to help. Let us simplify your daily routine so you can focus on the things that matter most.
         </p>

      </div>

    </section>
  )
}

export default About
