import Nav from "./components/Nav";
import { Outlet } from "react-router-dom";
import Footer from "./components/Footer";
import Chat from "./components/Chat";
const layout = () => {
  return (
    <>
      <Nav />
      <Outlet />
      <Footer />
      <div className="message flex_box">
        <Chat />
      </div>
    </>
  );
};

export default layout;
